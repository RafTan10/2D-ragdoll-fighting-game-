#!/usr/bin/env bash
# Renders every SVG in svg/ to a transparent 2x PNG in png/ using headless Edge (or Chrome via $BROWSER).
set -e
cd "$(dirname "$0")/.."
BROWSER="${BROWSER:-/c/Program Files (x86)/Microsoft/Edge/Application/msedge.exe}"
TMP="$(mktemp -d)"
mkdir -p png
for f in svg/*.svg; do
  n=$(basename "$f" .svg)
  read -r w h < <(sed -n 's/^<svg[^>]* width="\([0-9.]*\)" height="\([0-9.]*\)".*/\1 \2/p' "$f")
  # a fresh profile per file: Edge keeps the previous one locked for a moment after exiting
  "$BROWSER" --headless=new --disable-gpu --hide-scrollbars --user-data-dir="$(cygpath -w "$TMP/$n")" \
    --default-background-color=00000000 --force-device-scale-factor=2 --window-size="$w,$h" \
    --screenshot="$(cygpath -w "$PWD/png/$n.png")" "file:///$(cygpath -m "$PWD/$f")" >/dev/null 2>&1
  for _ in $(seq 50); do [ -f "png/$n.png" ] && break; sleep 0.2; done  # the launcher returns before the file lands
  [ -f "png/$n.png" ] && echo "png/$n.png" || echo "FAILED: $n"
done
rm -rf "$TMP" 2>/dev/null || true  # Edge may still hold a lockfile

# copy the sprites into the Unity folder, prefixed with the character name (nuha_head.png, ...)
CHAR=$(sed -n 's/^  "character": "\(.*\)",$/\1/p' rig.json)
lower=$(echo "$CHAR" | tr '[:upper:]' '[:lower:]')
mkdir -p "Unity/$CHAR/Sprites"
for f in png/*.png; do
  n=$(basename "$f")
  [ "${n#_}" = "$n" ] && cp "$f" "Unity/$CHAR/Sprites/${lower}_$n"
done
echo "Unity/$CHAR/Sprites updated"
