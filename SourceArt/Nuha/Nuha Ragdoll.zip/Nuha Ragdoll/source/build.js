// Builds the ragdoll: one SVG per body part, rig.json, an assembled preview image and preview.html.
// Run:  node source/build.js     then  bash source/export-png.sh   for the PNG sprites.
//
// Units: 1 unit = 1 px of the SVGs. PNGs are exported at 2x.
// Every part is drawn hanging straight down (or up, for the head) with its pivot joint at (0,0).
const fs = require('fs');
const path = require('path');

const CHARACTER = 'Nuha';
const ROOT = path.resolve(__dirname, '..');
const UNITY_DIR = path.join(ROOT, 'Unity', CHARACTER); // drag this folder into Assets/
const OUTLINE = '#1c1424';

// ---------------------------------------------------------------- shared paint
const DEFS = `<defs>
  <linearGradient id="skin" x1="0" x2="1">
    <stop offset="0" stop-color="#d49878"/><stop offset=".3" stop-color="#f0c3a4"/>
    <stop offset=".7" stop-color="#f0c3a4"/><stop offset="1" stop-color="#d49878"/>
  </linearGradient>
  <radialGradient id="face" cx=".5" cy=".42" r=".62">
    <stop offset="0" stop-color="#f5cbad"/><stop offset=".7" stop-color="#ebb594"/><stop offset="1" stop-color="#d69a7a"/>
  </radialGradient>
  <linearGradient id="hair" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#a9491f"/><stop offset=".55" stop-color="#8b3517"/><stop offset="1" stop-color="#6a2610"/>
  </linearGradient>
  <linearGradient id="leather" x1="0" x2="1">
    <stop offset="0" stop-color="#0d0d11"/><stop offset=".22" stop-color="#26262e"/><stop offset=".34" stop-color="#6c6c7a"/>
    <stop offset=".44" stop-color="#2b2b34"/><stop offset=".72" stop-color="#121217"/><stop offset=".9" stop-color="#30303a"/>
    <stop offset="1" stop-color="#0d0d11"/>
  </linearGradient>
  <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#f6d98a"/><stop offset=".5" stop-color="#c2902f"/><stop offset="1" stop-color="#7a5418"/>
  </linearGradient>
  <linearGradient id="sideShade" x1="0" x2="1">
    <stop offset="0" stop-color="#000" stop-opacity=".4"/><stop offset=".22" stop-color="#000" stop-opacity="0"/>
    <stop offset=".78" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".4"/>
  </linearGradient>
  <pattern id="floral" width="40" height="40" patternUnits="userSpaceOnUse" patternTransform="rotate(-8)">
    <rect width="40" height="40" fill="#28214d"/>
    <g fill="#e2742b"><circle cx="11" cy="6.5" r="3.6"/><circle cx="15.3" cy="9.6" r="3.6"/><circle cx="13.6" cy="14.6" r="3.6"/><circle cx="8.4" cy="14.6" r="3.6"/><circle cx="6.7" cy="9.6" r="3.6"/></g>
    <circle cx="11" cy="11" r="2.2" fill="#f2c14e"/>
    <ellipse cx="25" cy="8" rx="6" ry="2.4" fill="#2f8c7c" transform="rotate(-35 25 8)"/>
    <ellipse cx="6" cy="27" rx="5" ry="2.2" fill="#3a9a5a" transform="rotate(40 6 27)"/>
    <g fill="#c9303c"><circle cx="28" cy="23" r="3.2"/><circle cx="32" cy="26" r="3.2"/><circle cx="30.5" cy="31" r="3.2"/><circle cx="25.5" cy="31" r="3.2"/><circle cx="24" cy="26" r="3.2"/></g>
    <circle cx="28" cy="27.4" r="1.8" fill="#f2c14e"/>
    <circle cx="19" cy="20" r="1.6" fill="#e9a23b"/><circle cx="36" cy="15" r="1.4" fill="#8c5bb5"/>
    <circle cx="14" cy="34" r="1.5" fill="#e2742b"/><circle cx="2" cy="4" r="1.3" fill="#2f8c7c"/>
    <circle cx="34" cy="37" r="1.2" fill="#f2c14e"/>
  </pattern>
  <pattern id="croc" width="10" height="8" patternUnits="userSpaceOnUse">
    <rect width="10" height="8" fill="#7a1d27"/>
    <g fill="#5a121a" stroke="#93303a" stroke-width=".5">
      <rect x=".6" y=".6" width="4.2" height="3" rx="1.2"/><rect x="5.4" y=".6" width="4" height="3" rx="1.2"/>
      <rect x="2.8" y="4.4" width="4.4" height="3" rx="1.2"/><rect x="7.8" y="4.4" width="3.4" height="3" rx="1.2"/>
      <rect x="-1.4" y="4.4" width="3.6" height="3" rx="1.2"/>
    </g>
  </pattern>
</defs>`;

// ---------------------------------------------------------------- part artwork (local coords, pivot at 0,0)
const eye = (cx, side) => {
  const almond = `M${cx - 8},-48 Q${cx},-57 ${cx + 8},-48 Q${cx},-42 ${cx - 8},-48 Z`;
  const outer = cx + side * 8;
  return `
  <path d="M${cx - 9},-48.5 Q${cx},-60 ${cx + 9},-48.5 Q${cx},-56 ${cx - 9},-48.5 Z" fill="#b3604a" opacity=".35"/>
  <clipPath id="eye${cx}"><path d="${almond}"/></clipPath>
  <path d="${almond}" fill="#fbf6f2"/>
  <g clip-path="url(#eye${cx})">
    <circle cx="${cx}" cy="-48.6" r="4.4" fill="#3a1f14"/><circle cx="${cx}" cy="-48.6" r="2" fill="#0c0606"/>
    <circle cx="${cx + 1.4}" cy="-50.2" r="1.1" fill="#fff"/>
  </g>
  <path d="M${cx - 8},-48 Q${cx},-57 ${cx + 8},-48 L${outer + side * 3},-50.6" fill="none" stroke="#1a0f0c" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M${cx - 6.5},-46 Q${cx},-43.4 ${cx + 6.5},-46" fill="none" stroke="#a86f58" stroke-width=".7"/>`;
};

const freckles = [[-22, -40], [-18, -42], [-15, -39], [-20, -37], [-24, -36], [-17, -35],
  [22, -40], [18, -42], [15, -39], [20, -37], [24, -36], [17, -35], [-3, -42], [3, -42], [0, -44]]
  .map(([x, y]) => `<circle cx="${x}" cy="${y}" r=".9"/>`).join('');

const ART = {
  hair_back: {
    vb: [-58, -136, 116, 250],
    body: `
  <path d="M2,-104 C0,-124 18,-134 34,-128 C27,-124 24,-118 26,-110 C20,-114 13,-110 11,-103 Z" fill="url(#hair)" stroke="${OUTLINE}" stroke-width="2"/>
  <ellipse cx="7" cy="-105" rx="6" ry="3.5" fill="#15121a"/>
  <path d="M-38,-60 C-46,-100 -24,-112 0,-112 C24,-112 46,-100 38,-60 C46,-20 50,30 48,70 Q46,90 52,104 Q36,96 30,107 Q22,96 12,104 Q0,96 -10,104 Q-22,96 -30,107 Q-38,96 -52,104 Q-46,90 -48,70 C-50,30 -46,-20 -38,-60 Z" fill="url(#hair)" stroke="${OUTLINE}" stroke-width="2" stroke-linejoin="round"/>
  <g fill="none" stroke="#5e210d" stroke-width="1.5" opacity=".6">
    <path d="M-30,-40 Q-38,20 -36,92"/><path d="M30,-40 Q38,20 36,92"/><path d="M-20,0 Q-24,50 -20,100"/><path d="M20,0 Q24,50 20,100"/>
  </g>
  <path d="M-40,-30 Q-44,20 -44,80" fill="none" stroke="#c0602e" stroke-width="2" opacity=".6"/>`,
  },
  head: {
    vb: [-46, -112, 92, 104],
    body: `
  <ellipse cx="-31" cy="-46" rx="6" ry="9" fill="#e7b090" stroke="${OUTLINE}" stroke-width="1.5"/>
  <ellipse cx="31" cy="-46" rx="6" ry="9" fill="#e7b090" stroke="${OUTLINE}" stroke-width="1.5"/>
  <path d="M0,-13 C-17,-13 -31,-29 -32,-52 C-33,-80 -18,-94 0,-94 C18,-94 33,-80 32,-52 C31,-29 17,-13 0,-13 Z" fill="url(#face)" stroke="${OUTLINE}" stroke-width="2"/>
  <ellipse cx="-19" cy="-34" rx="7" ry="4" fill="#e57a72" opacity=".35"/>
  <ellipse cx="19" cy="-34" rx="7" ry="4" fill="#e57a72" opacity=".35"/>
  <g fill="#a8634a" opacity=".7">${freckles}</g>
  <path d="M-21,-59 Q-13,-64.5 -5,-60.5" fill="none" stroke="#3b1d12" stroke-width="3.2" stroke-linecap="round"/>
  <path d="M21,-59 Q13,-64.5 5,-60.5" fill="none" stroke="#3b1d12" stroke-width="3.2" stroke-linecap="round"/>
  ${eye(-12, -1)}
  ${eye(12, 1)}
  <path d="M-2,-46 Q-3,-41 -3.5,-38" fill="none" stroke="#d29a7e" stroke-width="1.2" stroke-linecap="round"/>
  <path d="M-3.2,-35.5 Q0,-33.8 3.2,-35.5" fill="none" stroke="#b5765c" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M-10,-25 Q-5,-29.5 0,-26.6 Q5,-29.5 10,-25 Q0,-23.5 -10,-25 Z" fill="#a3182a"/>
  <path d="M-10,-25 Q0,-23.5 10,-25 Q6,-18.5 0,-18.5 Q-6,-18.5 -10,-25 Z" fill="#c42433"/>
  <path d="M-10,-25 Q0,-23.5 10,-25" fill="none" stroke="#6e0f1a" stroke-width=".8"/>
  <ellipse cx="2" cy="-21.6" rx="3" ry="1" fill="#fff" opacity=".35"/>
  <path d="M-37,-34 C-42,-70 -30,-106 0,-108 C30,-106 42,-70 37,-34 C34,-42 32,-52 28,-60 Q24,-72 20,-74 Q17,-69 14,-65 Q12,-73 7,-76 Q5,-71 2,-67 Q-1,-74 -5,-77 Q-7,-71 -10,-66 Q-13,-74 -17,-76 Q-21,-70 -25,-64 Q-29,-58 -31,-50 C-33,-44 -35,-38 -37,-34 Z" fill="url(#hair)" stroke="${OUTLINE}" stroke-width="2" stroke-linejoin="round"/>
  <g fill="none" stroke-linecap="round">
    <path d="M-10,-100 Q-20,-88 -24,-72" stroke="#c0602e" stroke-width="1.5" opacity=".75"/>
    <path d="M8,-102 Q18,-90 21,-76" stroke="#c0602e" stroke-width="1.5" opacity=".75"/>
    <path d="M-2,-104 Q-6,-92 -7,-79" stroke="#c0602e" stroke-width="1.5" opacity=".75"/>
    <path d="M-22,-96 Q-30,-84 -32,-60" stroke="#d98042" stroke-width="2" opacity=".7"/>
    <path d="M24,-94 Q33,-80 34,-50" stroke="#5e210d" stroke-width="1.5" opacity=".6"/>
  </g>
  <circle cx="-32" cy="-32" r="4.5" fill="url(#gold)" stroke="#5a3a10" stroke-width="1"/><circle cx="-32" cy="-32" r="1.6" fill="#5a3a10"/>
  <circle cx="32" cy="-32" r="4.5" fill="url(#gold)" stroke="#5a3a10" stroke-width="1"/><circle cx="32" cy="-32" r="1.6" fill="#5a3a10"/>`,
  },
  torso: (() => {
    const T = 'M-12,2 Q0,15 12,2 L30,4 Q40,7 43,16 L35,40 Q30,54 27,70 L28,100 Q40,130 46,168 Q37,173 28,168 Q19,174 9,169 Q0,174 -9,169 Q-19,174 -28,168 Q-37,173 -46,168 Q-40,130 -28,100 L-27,70 Q-30,54 -35,40 L-43,16 Q-40,7 -30,4 Z';
    const grommets = [66, 72, 78, 84, 90, 96].map(y => `<circle cx="-3.5" cy="${y}" r="1.1"/><circle cx="3.5" cy="${y}" r="1.1"/>`).join('');
    const petals = [0, 72, 144, 216, 288].map(a => {
      const r = a * Math.PI / 180;
      return `<circle cx="${(16 + Math.sin(r) * 3.4).toFixed(2)}" cy="${(82 - Math.cos(r) * 3.4).toFixed(2)}" r="2.8"/>`;
    }).join('');
    return {
      vb: [-50, -20, 100, 198],
      body: `
  <path d="M-8,-18 L8,-18 L9,-4 Q13,2 15,8 L-15,8 Q-13,2 -9,-4 Z" fill="url(#skin)" stroke="${OUTLINE}" stroke-width="1.5"/>
  <path d="M-8,-18 L8,-18 L8.5,-12 Q0,-8 -8.5,-12 Z" fill="#c4876a" opacity=".6"/>
  <rect x="-9.6" y="-10" width="19.2" height="5" rx="2" fill="#141218"/>
  <g fill="#d9b46a"><circle cx="-6" cy="-7.5" r=".9"/><circle cx="-2" cy="-7.5" r=".9"/><circle cx="2" cy="-7.5" r=".9"/><circle cx="6" cy="-7.5" r=".9"/></g>
  <circle cx="0" cy="-2.6" r="2.4" fill="none" stroke="#d9b46a" stroke-width="1"/>
  <clipPath id="tunicClip"><path d="${T}"/></clipPath>
  <path d="${T}" fill="url(#floral)"/>
  <g clip-path="url(#tunicClip)">
    <rect x="-50" y="0" width="100" height="176" fill="url(#sideShade)"/>
    <path d="M-14,104 Q-18,140 -21,172 M13,104 Q17,140 20,172 M0,106 L0,172" fill="none" stroke="#120c26" stroke-opacity=".45" stroke-width="1.4"/>
    <path d="M-46,165.5 Q-37,170.5 -28,165.5 Q-19,171.5 -9,166.5 Q0,171.5 9,166.5 Q19,171.5 28,165.5 Q37,170.5 46,165.5" fill="none" stroke="#8e1f2a" stroke-width="1.8"/>
  </g>
  <path d="${T}" fill="none" stroke="${OUTLINE}" stroke-width="2" stroke-linejoin="round"/>
  <path d="M-12,2 Q0,15 12,2" fill="none" stroke="#8e1f2a" stroke-width="1.8"/>
  <path d="M-29,64 Q0,58 29,64 L31,101 Q0,107 -31,101 Z" fill="#17141c" stroke="#000" stroke-width="1.4"/>
  <path d="M-20,62 L-21,103 M20,62 L21,103 M-10,60.5 L-10.5,104.5 M10,60.5 L10.5,104.5" stroke="#2d2935" stroke-width="1"/>
  <path d="M-27,66 Q0,60.5 27,66" fill="none" stroke="#4a4552" stroke-width="1"/>
  <path d="M-3.5,66 L3.5,72 L-3.5,78 L3.5,84 L-3.5,90 L3.5,96 M3.5,66 L-3.5,72 L3.5,78 L-3.5,84 L3.5,90 L-3.5,96" fill="none" stroke="#b08a4a" stroke-width="1"/>
  <g fill="#d9b46a">${grommets}</g>
  <ellipse cx="22.5" cy="86" rx="3.6" ry="1.6" fill="#3a8a4a" transform="rotate(35 22.5 86)"/>
  <ellipse cx="10" cy="77" rx="3.6" ry="1.6" fill="#3a8a4a" transform="rotate(35 10 77)"/>
  <g fill="#c9303c">${petals}</g>
  <circle cx="16" cy="82" r="1.7" fill="#f2c14e"/>`,
    };
  })(),
  // Limbs below are the screen-left (_L) versions; _R parts are mirrored copies.
  upper_arm: {
    vb: [-24, -18, 48, 92],
    body: `
  <path d="M-9,-2 L9,-2 L8,64 Q0,70 -8,64 Z" fill="url(#skin)" stroke="${OUTLINE}" stroke-width="1.6"/>
  <path d="M-15,-12 Q0,-16 15,-12 L21,30 Q14,35 7,31 Q0,36 -7,31 Q-14,35 -21,30 Z" fill="url(#floral)"/>
  <path d="M-15,-12 Q0,-16 15,-12 L21,30 Q14,35 7,31 Q0,36 -7,31 Q-14,35 -21,30 Z" fill="url(#sideShade)"/>
  <path d="M-19.5,28 Q-14,32.5 -7,28.8 Q0,33.5 7,28.8 Q14,32.5 19.5,28" fill="none" stroke="#8e1f2a" stroke-width="1.6"/>
  <path d="M-15,-12 Q0,-16 15,-12 L21,30 Q14,35 7,31 Q0,36 -7,31 Q-14,35 -21,30 Z" fill="none" stroke="${OUTLINE}" stroke-width="2" stroke-linejoin="round"/>`,
  },
  forearm: {
    vb: [-14, -12, 28, 96],
    body: `
  <path d="M-8,-4 Q0,-9 8,-4 L6.5,58 L-6.5,58 Z" fill="url(#skin)" stroke="${OUTLINE}" stroke-width="1.6"/>
  <path d="M-7,55 Q-9.5,66 -7,75 Q-3,82 2,81 Q7,78 7.5,68 L7,55 Z" fill="url(#skin)" stroke="${OUTLINE}" stroke-width="1.6"/>
  <path d="M6,60 Q12,62 11,70 Q10,73.5 6.5,71.5" fill="#efc0a0" stroke="${OUTLINE}" stroke-width="1.4"/>
  <path d="M-3,74 L-3,80 M0.5,75 L0.5,81 M4,73 L4,78" fill="none" stroke="#b9805f" stroke-width=".8"/>
  <g stroke="#3a250f" stroke-width=".5">
    <rect x="-8.4" y="39" width="16.8" height="2.6" rx="1.3" fill="url(#gold)"/>
    <rect x="-8.2" y="42.2" width="16.4" height="2.6" rx="1.3" fill="#7a2a1c"/>
    <rect x="-8" y="45.4" width="16" height="2.6" rx="1.3" fill="url(#gold)"/>
    <rect x="-7.8" y="48.6" width="15.6" height="2.6" rx="1.3" fill="#2e2620"/>
  </g>
  <g fill="#d9b46a"><circle cx="-5" cy="49.9" r=".6"/><circle cx="-2" cy="49.9" r=".6"/><circle cx="1" cy="49.9" r=".6"/><circle cx="4" cy="49.9" r=".6"/></g>`,
  },
  thigh: {
    vb: [-19, -15, 38, 118],
    body: `
  <path d="M-16,-8 Q0,-13 16,-8 L13,94 Q0,99 -13,94 Z" fill="url(#leather)" stroke="#050507" stroke-width="1.5"/>
  <path d="M-12,0 L-10,92" fill="none" stroke="#45454f" stroke-width=".9"/>
  <path d="M-6,8 Q-7,50 -5,86" fill="none" stroke="#fff" stroke-opacity=".16" stroke-width="3" stroke-linecap="round"/>
  <path d="M-8,84 Q0,88 8,84" fill="none" stroke="#4a4a56" stroke-width="1"/>`,
  },
  shin: {
    vb: [-26, -13, 52, 134],
    body: `
  <path d="M-10,98 Q-12,110 -5,117 Q0,119 5,117 Q12,110 10,98 Z" fill="#0b0b0e" stroke="#000" stroke-width="1.2"/>
  <path d="M-7,107 L7,112 M-7,112 L7,107" stroke="#3c3c48" stroke-width="1.2"/>
  <ellipse cx="-3" cy="114" rx="3" ry="1.2" fill="#fff" opacity=".18"/>
  <path d="M-13,-6 Q0,-11 13,-6 L11,48 Q13,78 23,104 Q12,109 0,108 Q-12,109 -23,104 Q-13,78 -11,48 Z" fill="url(#leather)" stroke="#050507" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M-10,0 L-9,48 Q-12,78 -20,102" fill="none" stroke="#45454f" stroke-width=".9"/>
  <path d="M-5,4 Q-6,40 -4,58 Q-2,84 -9,100" fill="none" stroke="#fff" stroke-opacity=".16" stroke-width="3" stroke-linecap="round"/>
  <path d="M-4,0 Q0,3 4,0" fill="none" stroke="#4a4a56" stroke-width="1"/>`,
  },
  bag: {
    vb: [-34, -4, 68, 72],
    body: `
  <path d="M-14,26 Q-14,0 0,0 Q14,0 14,26" fill="none" stroke="#2a0d10" stroke-width="3.4" stroke-linecap="round"/>
  <path d="M-11,26 Q-11,4 0,4 Q11,4 11,26" fill="none" stroke="#4a1a20" stroke-width="2" stroke-linecap="round"/>
  <path d="M-28,30 Q-30,22 -20,22 L20,22 Q30,22 28,30 L30,58 Q30,64 24,64 L-24,64 Q-30,64 -30,58 Z" fill="url(#croc)" stroke="#2a0d10" stroke-width="2" stroke-linejoin="round"/>
  <path d="M-28,30 Q-30,22 -20,22 L20,22 Q30,22 28,30 L30,58 Q30,64 24,64 L-24,64 Q-30,64 -30,58 Z" fill="url(#sideShade)"/>
  <path d="M-21,26 L21,26" stroke="#c8c8d0" stroke-width="1.2" stroke-dasharray="1.6 1"/>
  <circle cx="-14" cy="26" r="2.6" fill="none" stroke="#b9b9c0" stroke-width="1.5"/>
  <circle cx="14" cy="26" r="2.6" fill="none" stroke="#b9b9c0" stroke-width="1.5"/>
  <ellipse cx="-10" cy="36" rx="12" ry="5" fill="#fff" opacity=".12"/>`,
  },
};

// ---------------------------------------------------------------- skeleton in rest pose (neck at 0,0, y down)
const rad = d => d * Math.PI / 180;
const deg = r => r * 180 / Math.PI;
const add = (a, b) => [a[0] + b[0], a[1] + b[1]];
// side -1 = screen left (_L), +1 = screen right (_R); `out` = degrees swung outward from straight down
const down = (side, out, len) => [side * Math.sin(rad(out)) * len, Math.cos(rad(out)) * len];

const J = { neck: [0, 0], head: [0, -56], pelvis: [0, 128] };
for (const [s, side] of [['L', -1], ['R', 1]]) {
  J['shoulder_' + s] = [side * 36, 10];
  J['elbow_' + s] = add(J['shoulder_' + s], down(side, 8, 62));
  J['wrist_' + s] = add(J['elbow_' + s], down(side, 4, 58));
  J['hip_' + s] = [side * 17, 128];
  J['knee_' + s] = add(J['hip_' + s], down(side, 3, 92));
  J['ankle_' + s] = add(J['knee_' + s], down(side, 3, 98));
}
J.bag = add(J.wrist_L, [0, 44]); // the bag hangs from the screen-left hand, like in the photo

const PHYS = { // collision radius, mass (used by preview.html)
  neck: [12, 2], head: [40, 1.6], pelvis: [20, 2.4], bag: [20, 0.5],
  shoulder: [16, 2], elbow: [9, 1], wrist: [9, 0.8], hip: [16, 2.2], knee: [13, 1.2], ankle: [16, 1],
};

// limits are for the _L side, in degrees relative to the rest pose, positive = clockwise on screen
const PARTS = [
  { name: 'hair_back', art: 'hair_back', pivot: 'neck', end: 'head', localEnd: [0, -56], parent: 'head', follows: 'head' },
  { name: 'thigh_L', art: 'thigh', pivot: 'hip_L', end: 'knee_L', localEnd: [0, 92], parent: 'torso', limits: [-30, 95] },
  { name: 'thigh_R', art: 'thigh', pivot: 'hip_R', end: 'knee_R', localEnd: [0, 92], parent: 'torso', limits: [-30, 95] },
  { name: 'shin_L', art: 'shin', pivot: 'knee_L', end: 'ankle_L', localEnd: [0, 98], parent: 'thigh_L', limits: [-120, 15] },
  { name: 'shin_R', art: 'shin', pivot: 'knee_R', end: 'ankle_R', localEnd: [0, 98], parent: 'thigh_R', limits: [-120, 15] },
  { name: 'torso', art: 'torso', pivot: 'neck', end: 'pelvis', localEnd: [0, 128], parent: null },
  { name: 'bag', art: 'bag', pivot: 'wrist_L', end: 'bag', localEnd: [0, 44], parent: 'forearm_L' },
  { name: 'upper_arm_L', art: 'upper_arm', pivot: 'shoulder_L', end: 'elbow_L', localEnd: [0, 62], parent: 'torso', limits: [-40, 170] },
  { name: 'forearm_L', art: 'forearm', pivot: 'elbow_L', end: 'wrist_L', localEnd: [0, 58], parent: 'upper_arm_L', limits: [-150, 15] },
  { name: 'upper_arm_R', art: 'upper_arm', pivot: 'shoulder_R', end: 'elbow_R', localEnd: [0, 62], parent: 'torso', limits: [-40, 170] },
  { name: 'forearm_R', art: 'forearm', pivot: 'elbow_R', end: 'wrist_R', localEnd: [0, 58], parent: 'upper_arm_R', limits: [-150, 15] },
  { name: 'head', art: 'head', pivot: 'neck', end: 'head', localEnd: [0, -56], parent: 'torso', limits: [-45, 45] },
];

// Unity rigidbody mass and capsule collider (sprite-local SVG units, y down; direction 'v' or 'h')
const BODY = {
  head: { mass: 1.1, collider: { center: [0, -58], size: [76, 92], direction: 'v' } },
  torso: { mass: 3, collider: { center: [0, 70], size: [64, 150], direction: 'v' } },
  upper_arm: { mass: 0.5, collider: { center: [0, 30], size: [22, 76], direction: 'v' } },
  forearm: { mass: 0.4, collider: { center: [0, 38], size: [16, 88], direction: 'v' } },
  thigh: { mass: 1.1, collider: { center: [0, 44], size: [30, 104], direction: 'v' } },
  shin: { mass: 0.8, collider: { center: [0, 54], size: [30, 126], direction: 'v' } },
  bag: { mass: 0.3, collider: { center: [0, 42], size: [58, 44], direction: 'h' } },
};

const STICKS = [];
const torsoPts = ['neck', 'shoulder_L', 'shoulder_R', 'pelvis', 'hip_L', 'hip_R'];
torsoPts.forEach((a, i) => torsoPts.slice(i + 1).forEach(b => STICKS.push([a, b])));
STICKS.push(['neck', 'head'], ['wrist_L', 'bag']);
for (const s of ['L', 'R']) {
  STICKS.push(['shoulder_' + s, 'elbow_' + s], ['elbow_' + s, 'wrist_' + s], ['hip_' + s, 'knee_' + s], ['knee_' + s, 'ankle_' + s]);
}

// ---------------------------------------------------------------- outputs
const r2 = n => Math.round(n * 100) / 100;
const isRight = p => p.name.endsWith('_R');
const viewBox = p => {
  const vb = ART[p.art].vb;
  return isRight(p) ? [-(vb[0] + vb[2]), vb[1], vb[2], vb[3]] : vb;
};
const bodyOf = p => isRight(p) ? `<g transform="scale(-1,1)">${ART[p.art].body}</g>` : ART[p.art].body;
const svgDoc = (vb, inner) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="${vb[2]}" height="${vb[3]}" viewBox="${vb.join(' ')}">\n${DEFS}\n${inner}\n</svg>\n`;

const rot = p => Math.atan2(J[p.end][1] - J[p.pivot][1], J[p.end][0] - J[p.pivot][0]) - Math.atan2(p.localEnd[1], p.localEnd[0]);
const byName = Object.fromEntries(PARTS.map(p => [p.name, p]));

fs.mkdirSync(path.join(ROOT, 'svg'), { recursive: true });
const sprites = {};
const rigParts = PARTS.map((p, z) => {
  const vb = viewBox(p);
  const svg = svgDoc(vb, bodyOf(p));
  fs.writeFileSync(path.join(ROOT, 'svg', p.name + '.svg'), svg);
  sprites[p.name] = 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64');

  const restRot = rot(p);
  const parent = p.parent && byName[p.parent];
  let anchor = null, restRel = 0;
  if (parent) {
    const pr = rot(parent), d = [J[p.pivot][0] - J[parent.pivot][0], J[p.pivot][1] - J[parent.pivot][1]];
    anchor = [r2(d[0] * Math.cos(-pr) - d[1] * Math.sin(-pr)), r2(d[0] * Math.sin(-pr) + d[1] * Math.cos(-pr))];
    restRel = restRot - pr;
  }
  const limits = p.limits && (isRight(p) ? [-p.limits[1], -p.limits[0]] : p.limits);
  return {
    name: p.name, z,
    svg: `svg/${p.name}.svg`, png: `png/${p.name}.png`,
    viewBox: vb,
    sizePx: [vb[2] * 2, vb[3] * 2],
    pivotPx: [-vb[0] * 2, -vb[1] * 2],
    pivotNormalized: [r2(-vb[0] / vb[2] * 1000) / 1000, r2((1 + vb[1] / vb[3]) * 1000) / 1000],
    pivotJoint: p.pivot, endJoint: p.end, localEnd: p.localEnd,
    restPivot: J[p.pivot].map(r2),
    parent: p.parent, anchorInParent: anchor,
    restRotationDeg: r2(deg(restRot)), restRotationRelDeg: r2(deg(restRel)),
    limitsDeg: limits || null,
    follows: p.follows || null,
    mass: BODY[p.art] ? BODY[p.art].mass : 0,
    collider: BODY[p.art] ? BODY[p.art].collider : null,
  };
});

const rig = {
  character: CHARACTER,
  footY: Math.max(...Object.entries(J).map(([k, v]) => v[1] + (PHYS[k] || PHYS[k.replace(/_[LR]$/, '')])[0])),
  notes: [
    '1 unit = 1 px of the SVGs; PNGs are 2x. Joint positions are the rest pose with the neck at (0,0), y pointing down.',
    'pivotPx is from the PNG top-left. pivotNormalized is bottom-left based (Unity sprite pivot).',
    'Angles are degrees, positive = clockwise on screen (y down). In y-up engines (Unity, Box2D) negate them and swap min/max.',
    'limitsDeg are relative to the rest pose (restRotationRelDeg). hair_back renders with the head (same pivot & rotation), behind everything.',
    'restPivot is where each part sits in the rest pose. footY is the bottom of the shoes (the prefab origin in Unity).',
  ],
  joints: Object.fromEntries(Object.entries(J).map(([k, v]) => {
    const ph = PHYS[k] || PHYS[k.replace(/_[LR]$/, '')];
    return [k, { x: r2(v[0]), y: r2(v[1]), radius: ph[0], mass: ph[1] }];
  })),
  sticks: STICKS,
  parts: rigParts,
};
fs.writeFileSync(path.join(ROOT, 'rig.json'), JSON.stringify(rig, null, 2));
fs.mkdirSync(UNITY_DIR, { recursive: true });
// Unity's JsonUtility only needs the parts; leave out the joint map and the nested stick arrays
const { joints, sticks, ...unityRig } = rig;
fs.writeFileSync(path.join(UNITY_DIR, CHARACTER.toLowerCase() + '_rig.json'), JSON.stringify(unityRig, null, 2));

// whole character in rest pose, for a quick look
const assembled = PARTS.map(p => {
  const [x, y] = J[p.pivot];
  return `<g transform="translate(${r2(x)} ${r2(y)}) rotate(${r2(deg(rot(p)))})">${bodyOf(p)}</g>`;
}).join('\n');
fs.writeFileSync(path.join(ROOT, 'svg', '_assembled.svg'), svgDoc([-80, -140, 160, 480], assembled));

const tpl = fs.readFileSync(path.join(__dirname, 'preview.template.html'), 'utf8');
fs.writeFileSync(path.join(ROOT, 'preview.html'), tpl.replace('/*__DATA__*/null', JSON.stringify({ rig, sprites })));

console.log('wrote', PARTS.length, 'parts, rig.json, svg/_assembled.svg, preview.html');
