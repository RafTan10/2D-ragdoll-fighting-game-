using UnityEngine;

/// <summary>
/// Root of a 2D ragdoll built by Ragdoll2DBuilder. Keeps the body parts from colliding with each other
/// and has a few helpers for game code.
/// </summary>
public class Ragdoll2D : MonoBehaviour
{
    [Tooltip("Let body parts collide with each other. Parts joined by a hinge never collide.")]
    public bool selfCollision;

    Rigidbody2D[] bodies;

    public Rigidbody2D[] Bodies => bodies ??= GetComponentsInChildren<Rigidbody2D>();

    void Awake()
    {
        if (selfCollision) return;
        var colliders = GetComponentsInChildren<Collider2D>();
        for (var i = 0; i < colliders.Length; i++)
            for (var j = i + 1; j < colliders.Length; j++)
                Physics2D.IgnoreCollision(colliders[i], colliders[j]);
    }

    /// <summary>Adds the same velocity change to every part, e.g. Launch(new Vector2(4, 8)) throws the whole body.</summary>
    public void Launch(Vector2 velocityChange)
    {
        foreach (var body in Bodies) body.AddForce(velocityChange * body.mass, ForceMode2D.Impulse);
    }

    /// <summary>Finds a body part by name: head, torso, upper_arm_L, forearm_R, thigh_L, shin_R, bag...</summary>
    public Rigidbody2D Part(string partName)
    {
        foreach (var body in Bodies)
            if (body.name == partName) return body;
        return null;
    }
}
