using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

/// <summary>
/// Builds a 2D ragdoll prefab (sprites, Rigidbody2D, CapsuleCollider2D, HingeJoint2D) from a *_rig.json file.
/// Expects the rig's sprites next to it in Sprites/{character}_{part}.png.
/// Use: Tools > Ragdoll 2D > Build All Prefabs, or right-click a *_rig.json > Build 2D Ragdoll Prefab.
/// </summary>
public static class Ragdoll2DBuilder
{
    // Sprites are exported at 2x, so one rig unit is 2 px. 500 px per unit makes a character ~1.85 units tall.
    const float PixelsPerUnit = 500f;
    const float RigToUnity = 2f / PixelsPerUnit;

    [Serializable] class Rig { public string character; public float footY; public Part[] parts; }

    [Serializable] class Part
    {
        public string name;
        public int z;
        public string parent;
        public string follows;
        public float[] pivotNormalized;
        public float[] restPivot;
        public float[] anchorInParent;
        public float restRotationDeg;
        public float[] limitsDeg;
        public float mass;
        public PartCollider collider;
    }

    [Serializable] class PartCollider { public float[] center; public float[] size; public string direction; }

    [MenuItem("Tools/Ragdoll 2D/Build All Prefabs")]
    static void BuildAll()
    {
        var found = false;
        foreach (var guid in AssetDatabase.FindAssets("_rig t:TextAsset"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (!path.EndsWith("_rig.json")) continue;
            found = true;
            Build(path);
        }
        if (!found) Debug.LogWarning("Ragdoll 2D: no *_rig.json files found in the project.");
    }

    [MenuItem("Assets/Build 2D Ragdoll Prefab")]
    static void BuildSelected() => Build(AssetDatabase.GetAssetPath(Selection.activeObject));

    [MenuItem("Assets/Build 2D Ragdoll Prefab", true)]
    static bool BuildSelectedValidate() =>
        Selection.activeObject is TextAsset && AssetDatabase.GetAssetPath(Selection.activeObject).EndsWith("_rig.json");

    public static GameObject Build(string rigPath)
    {
        var rig = JsonUtility.FromJson<Rig>(File.ReadAllText(rigPath));
        var dir = Path.GetDirectoryName(rigPath).Replace('\\', '/');
        var prefix = rig.character.ToLowerInvariant() + "_";

        var root = new GameObject(rig.character);
        try
        {
            root.AddComponent<Ragdoll2D>();
            var objects = new Dictionary<string, GameObject>();

            foreach (var p in rig.parts)
            {
                var go = new GameObject(p.name);
                go.transform.SetParent(root.transform, false);
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = ImportSprite($"{dir}/Sprites/{prefix}{p.name}.png", p.pivotNormalized);
                sr.sortingOrder = p.z;
                objects[p.name] = go;
            }

            foreach (var p in rig.parts)
            {
                var go = objects[p.name];
                if (!string.IsNullOrEmpty(p.follows))
                {
                    // decorative layer (the long hair): rides along with the part it follows, no physics
                    go.transform.SetParent(objects[p.follows].transform, false);
                    continue;
                }
                go.transform.localPosition = ToUnity(p.restPivot[0], p.restPivot[1] - rig.footY);
                go.transform.localRotation = Quaternion.Euler(0, 0, -p.restRotationDeg);

                var body = go.AddComponent<Rigidbody2D>();
                body.mass = p.mass;
                body.interpolation = RigidbodyInterpolation2D.Interpolate;
                body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

                if (p.collider != null && p.collider.size != null && p.collider.size.Length == 2)
                {
                    var capsule = go.AddComponent<CapsuleCollider2D>();
                    capsule.offset = ToUnity(p.collider.center[0], p.collider.center[1]);
                    capsule.size = new Vector2(p.collider.size[0], p.collider.size[1]) * RigToUnity;
                    capsule.direction = p.collider.direction == "h" ? CapsuleDirection2D.Horizontal : CapsuleDirection2D.Vertical;
                }
            }

            var limitSign = MeasureLimitSign();
            foreach (var p in rig.parts)
            {
                if (string.IsNullOrEmpty(p.parent) || !string.IsNullOrEmpty(p.follows)) continue;
                var hinge = objects[p.name].AddComponent<HingeJoint2D>();
                hinge.connectedBody = objects[p.parent].GetComponent<Rigidbody2D>();
                hinge.autoConfigureConnectedAnchor = false;
                hinge.anchor = Vector2.zero; // every part's pivot is its joint
                hinge.connectedAnchor = ToUnity(p.anchorInParent[0], p.anchorInParent[1]);
                hinge.enableCollision = false;
                if (p.limitsDeg != null && p.limitsDeg.Length == 2)
                {
                    float a = p.limitsDeg[0] * limitSign, b = p.limitsDeg[1] * limitSign;
                    hinge.limits = new JointAngleLimits2D { min = Mathf.Min(a, b), max = Mathf.Max(a, b) };
                    hinge.useLimits = true;
                }
            }

            var prefabPath = $"{dir}/{rig.character}.prefab";
            var prefab = PrefabUtility.SaveAsPrefabAsset(root, prefabPath);
            Debug.Log($"Ragdoll 2D: built {prefabPath}", prefab);
            EditorGUIUtility.PingObject(prefab);
            return prefab;
        }
        finally
        {
            Object.DestroyImmediate(root);
        }
    }

    // rig space is y-down; Unity is y-up
    static Vector2 ToUnity(float x, float y) => new Vector2(x, -y) * RigToUnity;

    static Sprite ImportSprite(string path, float[] pivot)
    {
        var importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (importer == null) throw new FileNotFoundException("Ragdoll 2D: missing sprite " + path);
        var s = new TextureImporterSettings();
        importer.ReadTextureSettings(s);
        s.textureType = TextureImporterType.Sprite;
        s.spriteMode = (int)SpriteImportMode.Single;
        s.spritePixelsPerUnit = PixelsPerUnit;
        s.spriteAlignment = (int)SpriteAlignment.Custom;
        s.spritePivot = new Vector2(pivot[0], pivot[1]);
        s.spriteMeshType = SpriteMeshType.Tight;
        s.mipmapEnabled = false;
        s.alphaIsTransparency = true;
        importer.SetTextureSettings(s);
        importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    /// <summary>
    /// The rig's limits are clockwise-positive (y-down). Whether HingeJoint2D measures the child against the parent
    /// or the other way round decides the sign, so turn a test joint and see which way jointAngle moves.
    /// </summary>
    static float MeasureLimitSign()
    {
        var parent = new GameObject("~hinge-test-parent") { hideFlags = HideFlags.HideAndDontSave };
        var child = new GameObject("~hinge-test-child") { hideFlags = HideFlags.HideAndDontSave };
        try
        {
            var parentBody = parent.AddComponent<Rigidbody2D>();
            parentBody.bodyType = RigidbodyType2D.Static;
            child.AddComponent<Rigidbody2D>().gravityScale = 0;
            var hinge = child.AddComponent<HingeJoint2D>();
            hinge.connectedBody = parentBody;
            child.transform.rotation = Quaternion.Euler(0, 0, 30); // child turns 30° counter-clockwise
            Physics2D.SyncTransforms();
            var angle = hinge.jointAngle;
            if (Mathf.Abs(Mathf.Abs(angle) - 30f) < 5f) return angle > 0 ? -1f : 1f;
            Debug.LogWarning($"Ragdoll 2D: couldn't measure the hinge angle convention (got {angle}°); assuming child-relative-to-parent. " +
                             "If elbows and knees bend the wrong way, swap the sign in MeasureLimitSign.");
            return -1f;
        }
        finally
        {
            Object.DestroyImmediate(child);
            Object.DestroyImmediate(parent);
        }
    }
}
