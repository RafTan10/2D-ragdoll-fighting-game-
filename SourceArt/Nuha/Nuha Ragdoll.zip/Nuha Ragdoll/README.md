# Nuha – 2D ragdoll

## Unity (start here)
1. Copy the `Unity/Nuha` folder into your project's `Assets/` folder.
2. In Unity: **Tools → Ragdoll 2D → Build All Prefabs** (or right-click `nuha_rig.json` → **Build 2D Ragdoll Prefab**).
3. `Assets/Nuha/Nuha.prefab` appears. Drop it in a scene above some ground and press Play.

What the builder sets up:
- Sprite import: Pixels Per Unit 500, custom pivot at each joint. Nuha is about 1.9 units tall, and the prefab's origin is at the soles of the shoes.
- Each body part gets a Rigidbody2D, CapsuleCollider2D and SpriteRenderer, with sorting order set so parts draw back to front.
- HingeJoint2D connects each part to its parent, with angle limits so elbows and knees only bend one way. The bag is free to swing from the left hand.
- The long hair (`hair_back`) is a child of the head with no physics.
- Ragdoll2D on the root stops body parts colliding with each other. In code: `GetComponent<Ragdoll2D>().Launch(new Vector2(4, 8))` throws the whole body, and `.Part("head")` gets one part's Rigidbody2D.

If you change sprites or `nuha_rig.json`, run the menu item again; it overwrites the prefab.

## Other files
- `png/` – one transparent sprite per body part (2x resolution). `_assembled.png` is a reference of the whole character.
- `svg/` – the same parts as vectors.
- `rig.json` – joint positions, pivots, hierarchy, draw order (`z`), angle limits, masses and colliders.
- `preview.html` – a browser physics test (drag, throw, F fling, R reset, S slow-mo, B bones).
- `source/` – `node source/build.js` regenerates the rig, SVGs and preview. `bash source/export-png.sh` re-renders the PNGs and refreshes `Unity/Nuha/Sprites`.

Rig angles are clockwise-positive with y down. The Unity builder converts them for you.
